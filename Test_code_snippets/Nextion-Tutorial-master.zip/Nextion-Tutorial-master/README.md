# Nextion-Tutorial
Files for the Nextion Display Tutorial on Youtube
Please install the libraries provided here. Otherwise it might not work.

Youtube video: https://www.youtube.com/watch?v=2zDb9GMNKpM
